import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.Assertions.assertThrows

class EvalVisitorTest {

    @Test
    fun `write your tests here`() {
        TODO("write your tests here")
    }
}