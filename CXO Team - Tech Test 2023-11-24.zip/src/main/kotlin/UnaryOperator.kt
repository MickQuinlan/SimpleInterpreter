enum class UnaryOperator {
    NEGATION,
    LOGICAL_NOT
}